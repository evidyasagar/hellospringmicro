package com.example.helloworldspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloworldSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
